BEGIN
    UPDATE dept SET dname ='Production' WHERE deptno= 50;
    IF SQL%NOTFOUND THEN
      INSERT into department_master VALUES ( 50, �Production');
    END IF;
END;�
